<?php $__env->startSection('content'); ?>
<div class="container px-4 my-5">
    
    <div class="card">
        <div class="card-header">
            <h4>Your Orders</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Product Title</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Product Image</th>
                        <th>Payment Status</th>
                        <th>Delivery Status</th>
                        <th>Cancel Order</th>
                    </tr>
                </thead>
                <tbody>
                    <?php //$totalprice = 0; ?>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product_title); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>
                            <img src="<?php echo e(url('public/images/'. $item->image)); ?>" width="50px" height="50px" alt="">
                        </td>
                        <td><?php echo e($item->payment_status); ?></td>
                        <td><?php echo e($item->delivery_status); ?></td>
                        <td>
                            <?php if($item->delivery_status == 'Processing'): ?>
                            <a href="<?php echo e(url('cancel_order', $item->id)); ?>" onclick="return confirm('Are you sure to Cancel this Order!!!')" class="btn btn-danger">Cancel Order</a>
                            <?php else: ?>
                            <a href="#" class="btn btn-secondary" disabled>Cancel Order</a>
                            <?php endif; ?>
                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www-81\htdocs\edgecut\resources\views/showorder.blade.php ENDPATH**/ ?>