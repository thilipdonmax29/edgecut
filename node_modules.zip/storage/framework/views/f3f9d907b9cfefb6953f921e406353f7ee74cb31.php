<?php $__env->startSection('title', 'Website Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class="card mt-5">
        <div class="card-header">
            <h4>All Orders</h4>
        </div>
        <div class="text-center py-3 mt-3">
            <form action="<?php echo e(url('admin/search/')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" name="search" placeholder="Search For Order" style="
    display: inline-block;
    width: auto;
">
                <input type="submit" value="Search" class="btn btn-success">
            </form>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Product Title</th>
                        <th>Price</th>
                        <th>Quanity</th>
                        <th>Payment Status</th>
                        <th>Delivery Status</th>
                        <th>Image</th>
                        <th>Delivered</th>
                        <th>Print PDF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->address); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->product_title); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->payment_status); ?></td>
                        <td><?php echo e($item->delivery_status); ?></td>
                        <td>
                            <img src="<?php echo e(url('public/images/'. $item->image)); ?>" width="50px" height="50px" alt="">
                        </td>
                        <td>
                            <?php if($item->delivery_status=='Processing'): ?>
                            <a href="<?php echo e(url('admin/delivered/'.$item->id)); ?>" onclick="return confirm('Are you sure this product is delivered !!!')" class="btn btn-success">Delivered</a>
                            <?php else: ?>
                            <a href="#" class="btn btn-secondary" disabled>Delivered</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin/printpdf/'.$item->id)); ?>" class="btn btn-success">Print PDF</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="16" style="text-align: center;">No data found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www-81\htdocs\edgecut\resources\views/admin/order.blade.php ENDPATH**/ ?>