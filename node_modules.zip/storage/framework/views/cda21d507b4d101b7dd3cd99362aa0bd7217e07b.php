<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <a class="nav-link" href="<?php echo e(url('admin/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                
                

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseblog" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Blog
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseblog" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(url('admin/add-blog')); ?>">Add Blog</a>
                        <a class="nav-link" href="<?php echo e(url('admin/blog')); ?>">View Blog</a>
                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsepage" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Product
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsepage" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(url('admin/add-product')); ?>">Add Product</a>
                        <a class="nav-link" href="<?php echo e(url('admin/product')); ?>">View Product</a>
                    </nav>
                </div>

                <a class="nav-link" href="<?php echo e(url('admin/order')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-cart-shopping"></i></div>
                    Orders
                </a>

                


                
                
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Edgecut Dashboard
        </div>
    </nav>
</div>
<?php /**PATH D:\www-81\htdocs\edgecut\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>