<?php $__env->startSection('title'); ?>
    Furniture
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!-- furniture section -->

  <section class="furniture_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Our Furniture
        </h2>
        <p>
          which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't an
        </p>
      </div>
      <div class="row">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4">
          <div class="box">
            <div class="img-box">
              <img src="<?php echo e(url('public/images/'. $item->product_image)); ?>" alt="">
            </div>
            <div class="detail-box">
              <h5>
                <?php echo e($item->product_name); ?>

              </h5>
              <div class="price_box">
                <h6 class="price_heading">
                  <span>$</span> <?php echo e($item->product_price); ?>

                </h6>
                
              </div>
              <form action="<?php echo e(url('add-cart', $item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-md-6 mt-3">
                    <input type="number" name="quantity" value="1" min="1" id="" style="width: 100px;">
                  </div>
                  <div class="col-md-6 mt-3">
                    <input class="btn btn-primary" type="submit" value="Add to Cart">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="my-5">
            <?php echo $product->withQueryString()->links('pagination::bootstrap-5'); ?>

        </div>
        
      </div>
    </div>
  </section>

  <!-- end furniture section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www-81\htdocs\edgecut\resources\views/furniture.blade.php ENDPATH**/ ?>