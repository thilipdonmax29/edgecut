<?php $__env->startSection('content'); ?>
<div class="container px-4 my-5">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <h4>View Cart</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Product Title</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Product Image</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $totalprice = 0; ?>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product_title); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        
                        <td>
                            <img src="<?php echo e(url('public/images/'. $item->image)); ?>" width="50px" height="50px" alt="">
                        </td>
                        <td>
                            <a href="<?php echo e(url('remove_cart/'.$item->id)); ?>" onclick="return confirm('Are you sure to remove this product')" class="btn btn-danger">Remove</a>
                        </td>
                    </tr>
                    <?php $totalprice = $totalprice + $item->price;  ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-12">
                    <h4><strong>Total Price :</strong> <?php echo e($totalprice); ?></h4>
                </div>
            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 my-5">
            <a href="<?php echo e(url('cash_order')); ?>" class="btn btn-primary">Cash on Delivery</a>
            <a href="<?php echo e(url('stripe', $totalprice)); ?>" class="btn btn-primary">Pay Using Card</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www-81\htdocs\edgecut\resources\views/showcart.blade.php ENDPATH**/ ?>